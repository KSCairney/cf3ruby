$(document).on('turbolinks:load', function(){
    $('.notice').delay(1000).fadeOut(1000);
});
